

public class WoodworkingTool extends Tool
{
    public WoodworkingTool(String Name) {
        super(Name);
        this.name = Name;
        this.pricePerDay = 20;
        this.isRented = false;
    }
    
}