public class ProtectiveGear extends Extenstion
{
    public ProtectiveGear()
    {
        this.Price = 15;
    }
}