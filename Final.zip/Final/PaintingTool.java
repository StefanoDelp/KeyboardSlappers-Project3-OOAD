

public class PaintingTool extends Tool
{
    public PaintingTool(String Name) {
        super(Name);
        this.name = Name;
        this.pricePerDay = 25;
        this.isRented = false;
    }
    
}