public class Extenstion
{
    int Price;
}