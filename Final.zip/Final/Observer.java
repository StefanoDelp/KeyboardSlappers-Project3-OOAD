public abstract class Observer {
    protected Store store;
    public abstract void update();
}