public interface IExtenstion {
    int price();
    int Getmany();
}