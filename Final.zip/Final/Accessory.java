public class Accessory extends Extenstion
{
    public Accessory()
    {
        this.Price = 10;
    }
}